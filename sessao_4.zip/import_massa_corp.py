from imc_func import massa_corp

massa_corp(70, 1.80)
