for character in "Python":
    print(character)
